# 📤 دليل رفع الصور لموقع كيان

## 🚀 خطوات رفع الصور:

### الطريقة 1: عبر GitHub (مباشرة)
1. افتح https://github.com/ahmeddev-inc/Kayan_Final_Project
2. انتقل إلى مجلد `docs/assets/img/`
3. انقر على "Add file" → "Upload files"
4. اسحب وأفلت الصور في المجلد المناسب
5. اكتب رسالة commit مثل "إضافة صور الشركة"
6. انقر على "Commit changes"

### الطريقة 2: عبر Git (محلياً)
```bash
# 1. نسخ الصور إلى المجلد المناسب
cp /path/to/your/logo.png docs/assets/img/
cp /path/to/your/project1.jpg docs/assets/img/projects/residential/

# 2. إضافة ورفع الصور
cd docs
git add assets/img/
git commit -m "إضافة صور حقيقية للشركة"
git push origin main
assets/img/
├── logo.png              # الشعار الرئيسي (ضروري)
├── logo-light.png        # الشعار الفاتح (ضروري)
├── hero/                 # صور البطل الرئيسية
│   ├── main.jpg          # الصفحة الرئيسية
│   ├── central-ac.jpg    # تكييف مركزي
│   └── industrial.jpg    # تكييف صناعي
├── services/             # صور الخدمات
│   ├── central-ac/
│   ├── industrial-ac/
│   ├── vrf-systems/
│   └── maintenance/
├── projects/             # معرض المشاريع
│   ├── residential/      # مشاريع سكنية
│   ├── commercial/       # مشاريع تجارية
│   ├── industrial/       # مشاريع صناعية
│   └── healthcare/       # مشاريع صحية
├── team/                 # صور الفريق
│   ├── management/       # الإدارة
│   ├── engineers/        # المهندسون
│   ├── technicians/      # الفنيون
│   └── sales/            # المبيعات
├── brands/               # العلامات التجارية
│   ├── carrier.png
│   ├── daikin.png
│   ├── lg.png
│   ├── gree.png
│   └── midea.png
├── clients/              # شعارات العملاء
├── icons/                # الأيقونات
│   ├── favicon.ico
│   └── apple-touch-icon.png
└── gallery/              # معرض عام
    ├── installations/    # صور التركيبات
    ├── equipment/        # المعدات
    ├── workshops/        # ورش العمل
    ├── certificates/     # الشهادات
    └── events/           # الفعاليات
