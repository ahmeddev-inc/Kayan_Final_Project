#!/bin/bash
echo "🚀 بدء خادم تطوير موقع كيان..."
echo "📞 رقم الهاتف: 01022843422"
echo "📍 المسار: $(pwd)"
echo ""

# تشغيل خادم Python
python3 -m http.server 8000 --directory . &
SERVER_PID=$!

echo "✅ الخادم يعمل على: http://localhost:8000"
echo "📱 افتح المتصفح وادخل العنوان أعلاه"
echo ""
echo "🎯 لوقف الخادم: اضغط Ctrl+C"
echo ""

# انتظار لإيقاف الخادم
wait $SERVER_PID
