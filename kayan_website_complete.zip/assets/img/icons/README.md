# مكتبة الأيقونات

## الأيقونات الأساسية:
1. **favicon.ico** - أيقونة المتصفح (16x16, 32x32, 64x64)
2. **apple-touch-icon.png** - أيقونة iOS (180x180)
3. **android-chrome-192.png** - أيقونة أندرويد
4. **android-chrome-512.png** - أيقونة أندرويد كبيرة

## أيقونات الخدمات:
1. **service-central.png** - أيقونة التكييف المركزي
2. **service-industrial.png** - أيقونة التكييف الصناعي
3. **service-vrf.png** - أيقونة أنظمة VRF
4. **service-maintenance.png** - أيقونة الصيانة

## أيقونات التواصل:
1. **phone-icon.png** - أيقونة الهاتف
2. **whatsapp-icon.png** - أيقونة الواتساب
3. **email-icon.png** - أيقونة البريد
4. **location-icon.png** - أيقونة الموقع
