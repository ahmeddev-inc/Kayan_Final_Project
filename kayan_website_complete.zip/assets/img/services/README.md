# صور الخدمات

## لكل خدمة (4 صور):
1. **service-icon.png** - أيقونة الخدمة (200x200)
2. **service-showcase.jpg** - صورة عرض (800x600)
3. **service-detail-1.jpg** - صورة تفصيلية
4. **service-detail-2.jpg** - صورة تفصيلية إضافية

## الخدمات:
1. central-ac/ - التكييف المركزي
2. industrial-ac/ - التكييف الصناعي
3. vrf-systems/ - أنظمة VRF
4. maintenance/ - الصيانة والدعم
