# 🌟 موقع كيان للتبريد والتكييف

موقع إعلاني احترافي لشركة كيان متخصصة في أنظمة التبريد والتكييف.

## 🔗 الروابط المباشرة

- 🌐 **الموقع الرئيسي**: [https://ahmeddev-inc.github.io](https://ahmeddev-inc.github.io)
- 🏢 **عن الشركة**: [https://ahmeddev-inc.github.io/pages/about/company.html](pages/about/company.html)
- 📞 **اتصل بنا**: [https://ahmeddev-inc.github.io/pages/contact/contact.html](pages/contact/contact.html)

## 📁 هيكل الموقع

```
├── index.html              # الصفحة الرئيسية
├── styles/                 # أنماط CSS
├── scripts/               # سكريبتات JavaScript
├── pages/                 # الصفحات الفرعية
│   ├── about/            # صفحات عن الشركة
│   ├── services/         # الخدمات
│   ├── projects/         # المشاريع
│   └── contact/          # صفحات الاتصال
├── assets/               # الأصول (صور، أيقونات)
└── images/               # الصور العامة
```

## 🚀 كيفية التحديث

```bash
# سحب التحديثات (إذا كان هناك تعاون)
git pull origin main

# إضافة التغييرات
git add .

# عمل commit
git commit -m "وصف التحديث"

# رفع التغييرات
git push origin main
```

## 📞 للتواصل

- 📧 البريد الإلكتروني: ahmeddev8118@gmail.com
- 💼 GitHub: [ahmeddev-inc](https://github.com/ahmeddev-inc)

---

⚡ **تم التطوير بواسطة AhmedDev Inc.** 
